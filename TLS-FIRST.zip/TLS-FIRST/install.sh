apt update;
apt upgrade;
apt install node;
apt install nodejs;
apt install npm;

curl -sL https://deb.nodesource.com/setup_16.x | sudo bash - ;
sudo apt install nodejs;

npm i http;
npm i colors;
npm i url; 
npm i cluster;
npm i http2;
npm i fs;

